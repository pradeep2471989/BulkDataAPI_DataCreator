using NUnit.Framework;
using System.Diagnostics;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Net;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using RestSharp;
using Newtonsoft.Json;

namespace APIBulkDataLoad
{
    public class Tests
    {
        [Test]
        public void ExecuteFlow_myStateLogin()
        {
            var client = new RestClient(GlobalVariables.env_host);
            GlobalVariables myClass = new GlobalVariables();
            string ResultPathEF = @"C:\DataSet\ExecuteFlow_myStateLogin_log.csv";
            string CheckingFlag = string.Empty;
            GlobalVariables.CSV_Extracts();
            var csv = new StringBuilder();
            List<string> CustID = GlobalVariables.CustomerID;
            List<string> CustName = GlobalVariables.Name;
            int Counter = 0;
            List<string> MiddleWareHints = GlobalVariables.MiddleWareHints;
            string CheckFlag = string.Empty;
            foreach (var custID in CustID)
            {
                ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("Content-Type", GlobalVariables.ContentType); 
                request.AddHeader("customerNumber", custID.ToString());
                request.AddHeader("Ocp-Apim-Subscription-Key", myClass.Decrypt(GlobalVariables.Azure_Key));
                //Comment the below line if you don't want the effectiveTime.
                request.AddHeader("effectiveTime", GlobalVariables.effectiveTime); 
                request.AddParameter(GlobalVariables.ContentType,
                    "{'type':'executeFlow'," +
                    "'protocolVersion':'2.6'," +
                    "'lang':'en'," +
                    "'flow':'MyStateLogin'," +
                    "'hints':" +
                    "{'Accounts': " +
                    "[" + MiddleWareHints[Counter] + "]," +
                    "'PartyId':' " + CustName[Counter] + "','firstName':'" + CustName[Counter] + "'}}",
                        ParameterType.RequestBody);
                //Performanc Measure
                DateTime T = System.DateTime.UtcNow;
                IRestResponse response = client.Execute(request);
                //Performance Measure
                TimeSpan TT = System.DateTime.UtcNow - T;
                string ResponseMessage = response.Content.ToString();
                string CorrectedResponse = ResponseMessage.Replace(',', '|');
                //Setting_Up_Flags:
                if (ResponseMessage.Contains("200"))
                {
                    CheckFlag = "PASS";
                }
                else
                {
                    CheckFlag = "FAIL";
                }
                //Writing the into CSV:
                var first = DateTime.Now;
                var second = custID.ToString();
                var third = CheckFlag;
                var fourth = CorrectedResponse.ToString();
                var fifth = TT;
                var newLine = string.Format("{0},{1},{2},{3},{4}", first, second, third, fourth, fifth);
                csv.AppendLine(newLine);
                Counter += 1;
                File.WriteAllText(ResultPathEF, csv.ToString());
            }
            Assert.Pass();
        }
    }
}