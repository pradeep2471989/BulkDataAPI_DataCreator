﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Diagnostics;

namespace APIBulkDataLoad
{
    public class GlobalVariables
    {
        //API Headers and Environment Variables
        public static string PostmanURL = "https://gateway.api.tst.mystate.int/personetics/pserver/execute?";  //DEV or UAT environment -- PER11 or PER12 or PER15
        public static string PostmanChannel = "channel=MYSTATE_MOBILE_LIVE"; // API Channel
        public static string env_host = PostmanURL + PostmanChannel; 
        public static string ContentType = "application/json"; //API Content Type
        public static string effectiveTime = "02/20/2024 01:00";  //Effective Date for the insights to be triggered
        public static string Azure_Key = "AQAAANCMnd8BFdERjHoAwE/Cl+sBAAAAcg1K4IqBAEOwTkejJZc1qAQAAAACAAAAAAADZgAAwAAAABAAAABGrs8ilhGfOmqUY3oxm896AAAAAASAAACgAAAAEAAAANsly3PIaqlKUcKSn9bZxBI4AAAALi3ixh79Fwaj4TTmGv82WOOHZFibI6b3QY85V8zC26QyQgyih3LTuz8HrskYSeGr8EZh+aZ3DzoUAAAAviM87rvtCYhtHeApFTM3A227RQE=";
        public static List<string> CustomerID = new List<string>();
        public static List<string> Name = new List<string>();
        public static List<string> MiddleWareHints = new List<string>();
        public static string FileNameandPath = @"C:\DataSet\Personetics_Upgrade_AllCustoWITHMW_Hints_Master_Round2.csv";

        public static void CSV_Extracts()
        {
            using (var reader = new StreamReader(FileNameandPath))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    Name.Add("Perso-BULK-Automation");
                    CustomerID.Add(values[0]);
                    MiddleWareHints.Add(line.Substring(line.IndexOf("{", 1)));
                    //MiddleWareHints.Add(line.Substring(line.IndexOf("{", 1)).Replace("\"", "'"));
                }
            }
        }
        public string Encrypt(string text)
        {
            return Convert.ToBase64String(
                ProtectedData.Protect(
                    Encoding.Unicode.GetBytes(text), null, DataProtectionScope.LocalMachine));
        }
        public string Decrypt(string text)
        {
            return Encoding.Unicode.GetString(
                ProtectedData.Unprotect(
                    Convert.FromBase64String(text), null, DataProtectionScope.LocalMachine));
        }
    }
}
